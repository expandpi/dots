## ROFI for Athena BSPWM and GNOME

####  Note from the Author: Rofi is for BSPWM and gnome but works in most of the WM/DE. 

```
If you need to use in other wm then in powermenu file, change the `logout` `command` for whatever DE/WM you are using.
```
```
It's use betterlockscreen.
```

### I checked this rofi config in gnome and bspwm baremetal and it's working as expected.


##### Please open issue for any error or any improvement.

Installation:
```
wget https://raw.githubusercontent.com/Athena-OS/rofi/main/install.sh && chmod +x install.sh && ./install.sh
```
