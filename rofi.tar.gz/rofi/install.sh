## installing dependency
sudo pacman --noconfirm -S maim xclip mpd 

## making  directory
mkdir ~/.config/rofi_backup
mkdir ~/.htb


## installing rofi
mv ~/.config/rofi ~/.config_rofi_backup


## cloning rofi
cd ~/.config
git clone https://github.com/Athena-OS/rofi
cd rofi
find . -type f ! -name "*.rasi" -exec chmod +x {} + 
